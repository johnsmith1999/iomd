﻿
(function() {

var slideSpeed = 10;
var slideStep = 5;
var ajaxTimeoutVal = 30000;
var prefix = null;

var originalView = null;
var currentView = null;
var currentDialog = null;
var currentWidth = 0;
var currentHeight = 0;
var currentHash = location.hash;
var hashPrefix = "#_";
var navStackStartIndex = 0;
var navStack = [];
var checkTimer;
var screenHeight = 0;
window.xtscript = {
logging: false,
busy: false,
transitionMode: 'css',
httpHeaders: {
"X-Requested-With": "XMLHttpRequest"
},
prefixedProperty: [],
plugin: [],

ready : false,
v : function() {
return 1.1;
},
 init : function() {
init();
 },
showView: function(view, backwards) {
if (view) {
if (view == currentView) {
xtscript.busy = false;
return;
}

if (currentDialog) {
currentDialog.removeAttribute("selected");
xtscript.sendEvent("xtscript-blur", currentDialog);
currentDialog = null;
}

if (xtscript.hasClass(view, "dialog")) {
xtscript.sendEvent("xtscript-focus", view);
showDialog(view);
}
else {
xtscript.sendEvent("xtscript-load", view);
var fromView = currentView;
xtscript.sendEvent("xtscript-blur", currentView);
currentView = view;
xtscript.sendEvent("xtscript-focus", view);

if (fromView) {
setTimeout(slideViews, 0, fromView, view, backwards);
} else {
updateView(view, fromView);
}
}
}
},


gotoView: function(view, replace) {
var node, nodeId;

if (view instanceof HTMLElement) {
node = view;
nodeId = node.id;
} else {
nodeId = view;
node = xtscript.$('#'+nodeId);
}

if (!node) xtscript.log("gotoView: node is null");

if (!xtscript.busy) {
xtscript.busy = true;
var index = navStack.indexOf(nodeId);
var backwards = index != -1;
if (backwards) {
navStack.splice(index);
} else if (replace) navStack.pop();

xtscript.showView(node, backwards);
return false;
} else {
return true;
}
},
showViewById: function(viewId) {
xtscript.gotoView(viewId, false);
},
goBack: function(viewId) {
if (viewId) {
var a = navStack.length - (navStack.indexOf(viewId) + 1);
navStack = navStack.slice(0, (navStack.length - a));
if(window.history.length > navStackStartIndex)
window.history.go(-a);
else
xtscript.showView(viewId, true);
} else {
if(window.history.length - (navStackStartIndex-1) == 1) {
xtscript.showView(navStack.pop(), true);
} else {
navStack.pop();
window.history.go(-1);
}
}
return navStack;
},

showViewByHref: function(url, args, method, replace, callback , errorCallback) {

function successCb(ajaxResult) {
var frag = document.createElement("div");
frag.innerHTML = ajaxResult;
if (replace) {
replaceElementWithFrag(replace, frag);
xtscript.busy = false;
} else {
xtscript.insertViews(frag);
}

if (callback) {
xtscript.log('showViewByHref error callback');
setTimeout(callback, 1000, true);
}
}

function errorCb() {
xtscript.log('showViewByHref error callback');
xtscript.busy = false;
errorCallback();
}

if (!xtscript.busy) {
xtscript.busy = true;
xtscript.ajax(url, args, method, successCb, errorCb);
} else {
callback();
}
},
ajax: function(url, args, method, callback, errorCallback) {
var xhr = new XMLHttpRequest();
method = method ? method.toUpperCase() : "GET";
if (args && method == "GET") {
url = url + "?" + ajaxParam(args);
}
xhr.open(method, url, true);
if (callback) {
xhr.onreadystatechange = function() {
if(xhr.readyState==4 && !xhr.aborted)
{
if(xhr.status==200 && xhr.responseText) {
xhr.aborted = true;
callback(xhr.responseText);
} else if(xhr.status==0) {
ajaxTimeout();
}
}
};
}
var data = null;
if (args && method != "GET") {
xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
data = ajaxParam(args);
}
for (var header in xtscript.httpHeaders) {
xhr.setRequestHeader(header, xtscript.httpHeaders[header]);
}
xhr.send(data);
xhr.requestTimer = setTimeout(ajaxTimeout, ajaxTimeoutVal);
return xhr;

function ajaxTimeout() {
xhr.aborted = true;
if(errorCallback)
errorCallback(xhr);
}
},

insertViews: function(frag, go) {

var newfrag;
if(typeof frag==='string') {
newfrag = document.createElement('div');
newfrag.innerHTML = frag;
} else if(frag.nodeName.toLowerCase()=='section' && frag.getAttribute('data-title')) {
newfrag = document.createElement('div');
newfrag.appendChild(frag);
} else
newfrag = frag;

var nodes = newfrag.childNodes, targetView;
go = (go==false)?false:true;

xtscript.sendEvent("xtscript-beforeinsert", document.body, {
fragment: newfrag
});

for (var i = 0, inb = nodes.length; i < inb; i++) {
var child = nodes[i];
if (child && child.nodeName.toLowerCase()=='section') {
if (!child.id) child.id = "__" + (new Date().getTime()) + "__";

var clone = xtscript.$('#' + child.id);
var docNode;
if (clone) {
clone.parentNode.replaceChild(child, clone);
docNode = xtscript.$(child.id);
} else
docNode = document.body.appendChild(child);

xtscript.sendEvent("xtscript-afterinsert", document.body, {
insertedNode: docNode
});
fitHeight();
if (child.getAttribute("selected") == "true" || !targetView) targetView = child;
--i;
}
}

xtscript.sendEvent("xtscript-afterinsertend", document.body, {
fragment: newfrag
})

if (targetView && go) {
setTimeout(function() { xtscript.showView(targetView); }, 1);
}
},
getSelectedView: function() {
for (var child = document.body.firstChild; child; child = child.nextSibling) {
if (child.nodeType == 1 && child.getAttribute("selected") == "true") return child;
}
},
getAllViews: function() {
var nodes = document.body.children,
views = [];
if (nodes) {
for (var i = 0, inb = nodes.length; i < inb; i++) {
if (nodes[i].id && nodes[i].getAttribute('data-title')) {
views.push(nodes[i]);
}
}
return views;
} else return false;
},
isNativeUrl: function(url) {
var urlPatterns = [
new RegExp("^javascript:"),
new RegExp("^mailto:"),
new RegExp("^tel:"),
new RegExp("^sms:"),
new RegExp("^callto:"),
new RegExp("^skype:"),
new RegExp("^video:"),
new RegExp("^music:"),
new RegExp("^maps:"),
new RegExp("^feed:"),
new RegExp("^(http|https):\/\/itunes.apple.com\/"),
new RegExp("^(http|https):\/\/youtube.com\/watch\\?v="),
new RegExp("^(http|https):\/\/youtube.com\/v\/"),
new RegExp("^http:\/\/youtu.be\/"),
new RegExp("^(http|https):\/\/maps.google.com\/?"),
new RegExp("^(http|https):\/\/www.google.com\/maps\/?"),
new RegExp("^(http|https):\/\/facebook.com\/"),
new RegExp("^(http|https):\/\/twitter.com\/")
];
var out = false;
for (var i = 0; i < urlPatterns.length; i++) {
if (url.match(urlPatterns[i])) out = true;
}
return out;
},

hasClass: function(el, name) {
return ((el.className).indexOf(name) > -1)?true:false;
},
addClass: function(el, name) {
if (!xtscript.hasClass(el, name))
el.className += " "+name;
},
changeClass: function(el, name, newname) {
if (xtscript.hasClass(el, name)) el.className = el.className.replace(new RegExp('(\\s|^)' + name + '(\\s|$)'), ' '+newname+' ');
},
$: function(a) {
if(document.querySelectorAll) {
var res = document.querySelectorAll(a);
return (res.length==0)?null:((res.length==1 && '#'+res[0].id==a)?res[0]:res);
} else {
if (a.substr(0, 1) == '#') return (document.getElementById(a.substr(1))) ? document.getElementById(a.substr(1)) : null;
else if (a.substr(0, 1) == '.') return (document.getElementsByClassName(a.substr(1))) ? document.getElementsByClassName(a.substr(1)) : null;
else if (a.indexOf('.') > -1) {
var c = document.getElementsByTagName(a.split('.')[0]),
d = a.split('.')[1];
for (var i = 0, inb = c.length; i < inb; i++) {
if (c[i].className.indexOf(d) > -1) {
return c[i];
exit;
}
}
} else if (a) return (document.getElementsByTagName(a)) ? document.getElementsByTagName(a) : null;
}
},
log: function() {
if ((window.console != undefined) && xtscript.logging==true) console.log.apply(console, arguments);
},

findParent : function(node, localName) {
while (node && (node.nodeType != 1 || node.localName.toLowerCase() != localName))
node = node.parentNode;
return node;
},

sendEvent : function(type, node, props) {
if (node) {
var event = document.createEvent("UIEvent");
event.initEvent(type, false, false);
if (props) {
for (i in props) {
event[i] = props[i];
}
}
node.dispatchEvent(event);
}
xtscript.log('event sent: ' + type);
}
};
addEventListener("load", init, false);
function init()
{
if(!xtscript.ready)
{
xtscript.changeClass(xtscript.$('html')[0],'no-js','js');

xtscript.ready=true;
var a = document.createElement('div').style;
prefix = (a.WebkitTransform == '') ? 'webkit' : (a.MozTransform == '') ? 'moz' : (a.msTransform == '') ? 'ms' : (a.transform == '') ? 'none' : null;
if (xtscript.transitionMode == 'css') xtscript.transitionMode = (prefix) ? 'css' : 'js';
if (prefix == 'webkit') {
xtscript.prefixedProperty['transform'] = 'webkitTransform';
xtscript.prefixedProperty['transformDuration'] = 'webkitTransformDuration';
xtscript.prefixedProperty['transitionEnd'] = 'webkitTransitionEnd';
xtscript.prefixedProperty['animationStart'] = 'webkitAnimationStart';
xtscript.prefixedProperty['animationDuration'] = 'webkitAnimationDuration';
xtscript.prefixedProperty['animationEnd'] = 'webkitAnimationEnd';
} else if (prefix == 'moz') {
xtscript.prefixedProperty['transform'] = 'MozTransform';
xtscript.prefixedProperty['transformDuration'] = 'MozTransformDuration';
xtscript.prefixedProperty['transitionEnd'] = 'transitionend';
xtscript.prefixedProperty['animationStart'] = 'animationstart';
xtscript.prefixedProperty['animationDuration'] = 'animationduration';
xtscript.prefixedProperty['animationEnd'] = 'animationend';
} else if (prefix == 'ms') {
xtscript.prefixedProperty['transform'] = 'msTransform';
xtscript.prefixedProperty['transformDuration'] = 'msTransformDuration';
xtscript.prefixedProperty['transitionEnd'] = 'transitionend';
xtscript.prefixedProperty['animationStart'] = 'MSAnimationStart';
xtscript.prefixedProperty['animationDuration'] = 'MSAnimationDuration';
xtscript.prefixedProperty['animationEnd'] = 'MSAnimationEnd';
} else if (prefix == 'none') {
xtscript.prefixedProperty['transform'] = 'msTransform';
xtscript.prefixedProperty['transformDuration'] = 'msTransformDuration';
xtscript.prefixedProperty['transitionEnd'] = 'transitionend';
xtscript.prefixedProperty['animationStart'] = 'MSAnimationStart';
xtscript.prefixedProperty['animationDuration'] = 'MSAnimationDuration';
xtscript.prefixedProperty['animationEnd'] = 'MSAnimationEnd';
}

navStackStartIndex = history.length;
var defaultView = xtscript.getSelectedView();
var locViewId = location.hash.substr(hashPrefix.length);
var locView = (locViewId)?xtscript.$('#' + locViewId):null;

if (defaultView) {
xtscript.originalView = defaultView;
xtscript.showView(defaultView);
} else {
var views = xtscript.getAllViews();
xtscript.originalView = (views.length>0)?views[0]:false;
}
if (locView && (locView != defaultView))
xtscript.showView(locView);
if (typeof window.onorientationchange == "object") window.onorientationchange = resizeHandler;
else window.onresize = resizeHandler;
if ("onhashchange" in window) window.onhashchange = checkLocation;
else checkTimer = setInterval(checkLocation, 300);

setTimeout(function() {
preloadImages();
checkLocation();
fitHeight();
xtscript.sendEvent('xtscript-ready', document);
}, 1);
}
}

addEventListener("click", function(event) {
if (!xtscript.busy && !("onhashchange" in window)) checkTimer = setInterval(checkLocation, 300);

var link = xtscript.findParent(event.target, "a");
if (link) {
function unselect() {
link.removeAttribute("selected");
}
if (link.href && link.hash && link.hash != "#" && !link.target) {
followAnchor(link);
} else if (link == xtscript.$("#backButton")) {
link.setAttribute("selected", "true");
setTimeout(function() {
unselect();
}, 300);
xtscript.goBack();
} else if (link.target == "_replace") {
followAjax(link, link);
} else if (xtscript.isNativeUrl(link.href)) {
return;
} else if (link.target == "_webapp") {
location.href = link.href;
} else if (!link.target && link.getAttribute('href')) {
followAjax(link, null);
} else if (link.href == '' || !link.href) {
return;
} else {
return;
}
event.preventDefault();
}

var button = xtscript.findParent(event.srcElement, "button");
if (button && button.getAttribute("type") == "cancel") {
var view = xtscript.findParent(event.srcElement, "section");
if(xtscript.hasClass(view,'dialog'))
cancelDialog(view);
} else if(button && button.getAttribute("type") != "submit") {
event.preventDefault();
}
}, true);
addEventListener("submit", function(event) {
var form = event.target;
if (form.target != "_self") {
event.preventDefault();
submitForm(form);
}
}, true);

function followAnchor(link) {
link.setAttribute("selected", "true");
var busy = xtscript.gotoView(link.hash.substr(1), false);
setTimeout(function() {
link.removeAttribute("selected");
}, busy ? 0 : 500);
}

function followAjax(link, replaceLink) {
link.setAttribute("selected", "progress");
xtscript.showViewByHref(link.href, null, "GET", replaceLink, function() {
link.removeAttribute("selected");
}, function error() {
link.removeAttribute("selected");
});
}

function resizeHandler() {
fitHeight();
}

function checkLocation() {
if (location.hash != currentHash) {
var viewId = location.hash.substr(hashPrefix.length);
if ((viewId == "") && originalView)
viewId = originalView.id;
xtscript.showViewById(viewId);
}
}

function showDialog(view) {
scrollTo(0, 1);
currentDialog = view;
view.setAttribute("selected", "true");
if (xtscript.transitionMode == 'css') setTimeout(function() {
xtscript.addClass(view, 'show');
}, 1);
else xtscript.addClass(view, 'show');
showForm(view);
view.onclick = function(e) {
if (e.srcElement) {
if (xtscript.hasClass(e.srcElement, 'dialog')) cancelDialog(e.srcElement);
}
};
}

function cancelDialog(form) {
if (xtscript.transitionMode == 'css') {
setTimeout(function() {
xtscript.changeClass(form, 'show', '');
}, 1);
form.addEventListener(xtscript.prefixedProperty['transitionEnd'], hideForm, false);
} else {
xtscript.changeClass(form, 'show', '');
hideForm(form);
}
}

function showForm(form) {
form.addEventListener("click", function(event) {}, true);
xtscript.busy = false;
}

function hideForm(form) {
if (undefined == form.srcElement) {
form.removeAttribute("selected");
}
else {
var toolbarElement = xtscript.$('#'+form.srcElement.id+' .toolbar')[0];
toolbarElement.style.display = '';
form.srcElement.removeAttribute("selected");
form.srcElement.removeEventListener(xtscript.prefixedProperty['transitionEnd'], hideForm, false);
}
}

function updateView(view, fromView) {
if (!view.id) view.id = "__" + (new Date().getTime()) + "__";

currentHash = hashPrefix + view.id;
if (!fromView) {
location.replace(currentHash);
} else {
location.assign(currentHash);
}

navStack.push(view.id);

var viewTitle = xtscript.$('#viewTitle');
if (view.getAttribute('data-title')) {
viewTitle.innerHTML = view.getAttribute('data-title');
}

if (view.localName.toLowerCase() == "form") showForm(view);

var backButton = xtscript.$("#backButton");
if (backButton) {
var prevView = xtscript.$('#' + navStack[navStack.length - 2]);
if (prevView && !view.getAttribute("data-hidebackbutton")) {
backButton.style.display = "block";
backButton.innerHTML = (prevView.getAttribute('data-title')) ? prevView.getAttribute('data-title') : "Back";
} else backButton.style.display = "none";
}
xtscript.busy = false;
}


function canDoSlideAnim() {
return (xtscript.transitionMode != 'none') && (xtscript.prefixedProperty != null);
}
function slideViews(fromView, toView, backwards) {
scrollTo(0, 1);
clearInterval(checkTimer);

xtscript.sendEvent("xtscript-beforetransition", fromView, {
out: true
});
xtscript.sendEvent("xtscript-beforetransition", toView, {
out: false
});

if (xtscript.transitionMode == 'css') slideCSS(fromView, toView, backwards, slideDone);
else if (xtscript.transitionMode == 'js') slideJS(fromView, toView, backwards, slideDone);
else noSlide(fromView, toView, slideDone);

function slideDone() {
if (!xtscript.hasClass(toView, "dialog")) {
fromView.removeAttribute("selected");
fromView.removeAttribute('xtscript-transition');
toView.removeAttribute('xtscript-transition');
}

if (!("onhashchange" in window)) checkTimer = setInterval(checkLocation, 300);

setTimeout(updateView, 0, toView, fromView);
fromView.removeEventListener(xtscript.prefixedProperty['animationEnd'], slideDone, false);

if (fromView.getAttribute('data-onexit')) eval(fromView.getAttribute('data-onexit'));
if (toView.getAttribute('data-onshow')) eval(toView.getAttribute('data-onshow'));

xtscript.sendEvent("xtscript-aftertransition", fromView, {
out: true
});
xtscript.sendEvent("xtscript-aftertransition", toView, {
out: false
});

if (backwards) xtscript.sendEvent("xtscript-unload", fromView);
}
}

function slideJS(fromView, toView, backwards, cb) {
toView.style.left = "100%";
scrollTo(0, 1);
toView.setAttribute("selected", "true");
var percent = 100;

function slide() {
percent -= slideStep;
fromView.style.left = (backwards ? (100 - percent) : (percent - 100)) + "%";
toView.style.left = (backwards ? -percent : percent) + "%";
if (percent <= 0) {
clearInterval(slideInterval);
percent = 0;
cb();
}
}
var slideInterval = setInterval(slide, slideSpeed);
slide();
}

function slideCSS(fromView, toView, backwards, cb) {
toView.style.visibility = 'hidden';
if (!backwards) var transName = (toView.getAttribute('custom-transition')) ? toView.getAttribute('custom-transition') : 'slide';
else var transName = (fromView.getAttribute('custom-transition')) ? fromView.getAttribute('custom-transition') : 'slide';

var fromViewTransition = backwards ? (transName + 'backout') : (transName + 'out');
var toViewTransition = backwards ? (transName + 'backin') : (transName + 'in');
toView.setAttribute("selected", "true");

function startTrans() {
fromView.setAttribute('xtscript-transition', fromViewTransition);
toView.setAttribute('xtscript-transition', toViewTransition);
toView.style.visibility = '';
}
fromView.addEventListener(xtscript.prefixedProperty['animationEnd'], cb, false);
setTimeout(startTrans, 1);
}

function noSlide(fromView, toView, cb) {
setTimeout(function() {
fromView.removeAttribute("selected");
toView.setAttribute("selected", "true");
cb();
}, 1);
}

function submitForm(form) {
xtscript.addClass(form, "progress");
xtscript.sendEvent("xtscript-beforeformsubmit", document.body, {
form: form
})
xtscript.showViewByHref(form.getAttribute('action'), encodeForm(form), form.hasAttribute('method') ? form.getAttribute('method') : 'GET', null, function() {
xtscript.changeClass(form, 'progress', '');
cancelDialog(form);
xtscript.sendEvent("xtscript-afterformsubmit", document.body, {
form: form
})
});
}
function ajaxParam(o) {
var s = [];
for (var key in o) {
var value = o[key];
if (value != null && typeof(value) == "object" && typeof(value.length) == "number") {
for (var i = 0; i < value.length; i++) {
s[s.length] = encodeURIComponent(key) + '=' + encodeURIComponent(value[i]);
}
} else s[s.length] = encodeURIComponent(key) + '=' + encodeURIComponent(value);
}
return s.join("&").replace(/%20/g, "+");
}

function encodeForm(form) {
function encode(inputs) {
for (var i = 0; i < inputs.length; ++i) {
if (inputs[i].name) {
var input = inputs[i];
if (input.getAttribute("type") == "checkbox" && !input.checked || input.getAttribute("type") == "radio" && !input.checked || input.disabled) {
continue;
}
if (input.getAttribute("type") == "submit") {
if (input.getAttribute("submitvalue")) {
input.removeAttribute("submitvalue");
} else {
continue;
}
}
var value = args[input.name];
if (value === undefined) {
args[input.name] = input.value;
} else if (value instanceof Array) {
value.push(input.value);
} else {
args[input.name] = [value, input.value];
}
}
}
}

var args = {};
encode(form.getElementsByTagName("input"));
encode(form.getElementsByTagName("textarea"));
encode(form.getElementsByTagName("select"));
encode(form.getElementsByTagName("button"));
return args;
}

function replaceElementWithFrag(replace, frag) {
var parent = replace.parentNode;
var parentTarget = parent.parentNode;
parentTarget.removeChild(parent);

xtscript.sendEvent("beforereplace", document.body, {
fragment: frag
});

var docNode;
while (frag.firstChild) {
docNode = parentTarget.appendChild(frag.firstChild);
xtscript.sendEvent("afterreplace", document.body, {
insertedNode: docNode
});
}
xtscript.sendEvent("afterreplaceend", document.body, {
fragment: frag
});
}

function preloadImages() {
var preloader = document.createElement("div");
preloader.id = "preloader";
document.body.appendChild(preloader);
}

function fitHeight(a) {
window.scrollTo(0, 0);
if (screenHeight == 0) var wih = screenHeight;
else var wih = window.innerHeight;
setTimeout(function() {
var heightVal;
var toolbarHeight = xtscript.$('.toolbar')[0].clientHeight;
var sc = xtscript.$('body')[0].childNodes;
if (sc) {
for (var i = 1; i <= (sc.length - 1); i++) {
if ((sc[i].id != '') && (sc[i].id != undefined) && (typeof sc[i] === 'object') && !xtscript.hasClass(sc[i], 'toolbar')) {
heightVal = wih;
if (window.navigator.standalone === false) {
if (navigator.userAgent.toLowerCase().search('ipad') > -1) heightVal = (wih);
else if (xtscript.hasClass(sc[i], 'dialog')) heightVal = (wih + 60);
else if (screenHeight < 2) heightVal = (wih + 60);
} else {
if (navigator.userAgent.toLowerCase().search('android') > -1 && screenHeight == 0) heightVal = (wih + 50);
else if (navigator.userAgent.toLowerCase().search('firefox') > -1) heightVal = (wih - toolbarHeight);
}
sc[i].style.minHeight = heightVal + 'px';
}
}
}
if (screenHeight == 0) {
screenHeight = 1;
fitHeight();
} else if (screenHeight == 1) {
screenHeight = heightVal;
}
setTimeout(function() {
window.scrollTo(0, 1)
}, 1);

}, 1);

}

})();
